Budget 100; common scored population 8297 of 8324 held-out variants (314 disrupting, 460 groups); 27 excluded.

| Configuration | Scores | P@100 expected [range over tie orders] | Tied at cutoff | AP | AUROC |
|---|---|---|---:|---:|---:|
| prevalence | computed here (one training number) | 0.038 [0.00, 1.00] | 8297 | 0.038 | 0.500 |
| distance | computed here (no fitting) | 0.135 [0.00, 0.23] | 171 | 0.066 | 0.658 |
| kmer_assay | fitted here (training groups) | 0.570 [0.57, 0.57] | 1 | 0.274 | 0.787 |
| kmer_cons | fitted here (training groups) | 0.610 [0.61, 0.61] | 1 | 0.287 | 0.778 |
| S0 | saved-score replay (matched study) | 0.630 [0.63, 0.63] | 1 | 0.295 | 0.804 |
| S1 | saved-score replay (matched study) | 0.650 [0.65, 0.65] | 2 | 0.313 | 0.815 |
| P0 | saved-score replay (matched study) | 0.650 [0.65, 0.65] | 1 | 0.389 | 0.876 |
| P1 | saved-score replay (matched study) | 0.657 [0.65, 0.66] | 3 | 0.411 | 0.873 |
| kmer_assay_selected | fitted here (validation-selected settings) | 0.580 [0.58, 0.58] | 1 | 0.273 | 0.780 |
| kmer_cons_selected | fitted here (validation-selected settings) | 0.630 [0.63, 0.63] | 1 | 0.298 | 0.778 |

Paired contrasts against `kmer_cons_selected` (whole-group bootstrap, 95% percentile, unadjusted, exploratory):

| Contrast | P@100 | AP | AUROC |
|---|---|---|---|
| S0 - kmer_cons_selected | +0.000 [-0.086, +0.101] | -0.002 [-0.047, +0.048] | +0.026 [-0.009, +0.060] |
| S1 - kmer_cons_selected | +0.020 [-0.063, +0.111] | +0.015 [-0.031, +0.065] | +0.037 [+0.003, +0.070] |
| P0 - kmer_cons_selected | +0.020 [-0.046, +0.106] | +0.091 [+0.053, +0.131] | +0.098 [+0.073, +0.124] |
| P1 - kmer_cons_selected | +0.030 [-0.033, +0.117] | +0.113 [+0.074, +0.154] | +0.095 [+0.065, +0.126] |

Each bootstrap draw resamples whole groups and keeps the review fraction 100/8297, so realised shortlist depths ranged 83-126 (mean 99.9); the observed difference uses exactly 100.

Disrupting variants captured in each top 100 (registered tie order), by distance to the nearest junction in the construct; AUROC within band in brackets:

| Band (bases) | Variants | Disrupting | distance | kmer_assay | kmer_cons | S0 | S1 | P0 | P1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0-2 | 560 | 46 | 11 (0.63) | 23 (0.84) | 24 (0.83) | 26 (0.85) | 26 (0.87) | 25 (0.90) | 25 (0.90) |
| 3-10 | 1678 | 95 | 0 (0.38) | 26 (0.79) | 27 (0.77) | 28 (0.83) | 29 (0.85) | 32 (0.88) | 33 (0.89) |
| 11-30 | 4223 | 143 | 0 (0.67) | 8 (0.75) | 10 (0.75) | 9 (0.77) | 10 (0.79) | 8 (0.86) | 8 (0.86) |
| >30 | 1836 | 30 | 0 (0.52) | 0 (0.75) | 0 (0.75) | 0 (0.72) | 0 (0.71) | 0 (0.84) | 0 (0.83) |
