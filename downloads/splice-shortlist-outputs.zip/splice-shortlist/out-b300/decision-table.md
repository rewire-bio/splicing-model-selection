Budget 300; common scored population 8297 of 8324 held-out variants (314 disrupting, 460 groups); 27 excluded.

| Configuration | Scores | P@300 expected [range over tie orders] | Tied at cutoff | AP | AUROC |
|---|---|---|---:|---:|---:|
| prevalence | computed here (one training number) | 0.038 [0.00, 1.00] | 8297 | 0.038 | 0.500 |
| distance | computed here (no fitting) | 0.111 [0.08, 0.12] | 165 | 0.066 | 0.658 |
| kmer_assay | fitted here (training groups) | 0.310 [0.31, 0.31] | 1 | 0.274 | 0.787 |
| kmer_cons | fitted here (training groups) | 0.333 [0.33, 0.33] | 1 | 0.287 | 0.778 |
| S0 | saved-score replay (matched study) | 0.350 [0.35, 0.35] | 12 | 0.295 | 0.804 |
| S1 | saved-score replay (matched study) | 0.366 [0.36, 0.37] | 19 | 0.313 | 0.815 |
| P0 | saved-score replay (matched study) | 0.457 [0.44, 0.47] | 20 | 0.389 | 0.876 |
| P1 | saved-score replay (matched study) | 0.484 [0.48, 0.49] | 21 | 0.411 | 0.873 |
| kmer_assay_selected | fitted here (validation-selected settings) | 0.310 [0.31, 0.31] | 1 | 0.273 | 0.780 |
| kmer_cons_selected | fitted here (validation-selected settings) | 0.347 [0.35, 0.35] | 1 | 0.298 | 0.778 |

Paired contrasts against `kmer_cons` (whole-group bootstrap, 95% percentile, unadjusted, exploratory):

| Contrast | P@300 | AP | AUROC |
|---|---|---|---|
| S0 - kmer_cons | +0.017 [-0.030, +0.070] | +0.008 [-0.039, +0.058] | +0.026 [-0.008, +0.059] |
| S1 - kmer_cons | +0.030 [-0.016, +0.088] | +0.026 [-0.021, +0.077] | +0.037 [+0.005, +0.070] |
| P0 - kmer_cons | +0.127 [+0.080, +0.172] | +0.102 [+0.061, +0.142] | +0.099 [+0.073, +0.125] |
| P1 - kmer_cons | +0.150 [+0.099, +0.199] | +0.124 [+0.083, +0.165] | +0.095 [+0.067, +0.125] |

Each bootstrap draw resamples whole groups and keeps the review fraction 300/8297, so realised shortlist depths ranged 250-378 (mean 299.6); the observed difference uses exactly 300.

Disrupting variants captured in each top 300 (registered tie order), by distance to the nearest junction in the construct; AUROC within band in brackets:

| Band (bases) | Variants | Disrupting | distance | kmer_assay | kmer_cons | S0 | S1 | P0 | P1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0-2 | 560 | 46 | 34 (0.63) | 27 (0.84) | 29 (0.83) | 30 (0.85) | 30 (0.87) | 31 (0.90) | 31 (0.90) |
| 3-10 | 1678 | 95 | 0 (0.38) | 41 (0.79) | 46 (0.77) | 41 (0.83) | 45 (0.85) | 58 (0.88) | 60 (0.89) |
| 11-30 | 4223 | 143 | 0 (0.67) | 25 (0.75) | 25 (0.75) | 31 (0.77) | 31 (0.79) | 44 (0.86) | 48 (0.86) |
| >30 | 1836 | 30 | 0 (0.52) | 0 (0.75) | 0 (0.75) | 3 (0.72) | 3 (0.71) | 5 (0.84) | 6 (0.83) |
