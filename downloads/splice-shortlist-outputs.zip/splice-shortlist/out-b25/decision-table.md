Budget 25; common scored population 8297 of 8324 held-out variants (314 disrupting, 460 groups); 27 excluded.

| Configuration | Scores | P@25 expected [range over tie orders] | Tied at cutoff | AP | AUROC |
|---|---|---|---:|---:|---:|
| prevalence | computed here (one training number) | 0.038 [0.00, 1.00] | 8297 | 0.038 | 0.500 |
| distance | computed here (no fitting) | 0.135 [0.00, 0.92] | 171 | 0.066 | 0.658 |
| kmer_assay | fitted here (training groups) | 0.800 [0.80, 0.80] | 1 | 0.274 | 0.787 |
| kmer_cons | fitted here (training groups) | 0.720 [0.72, 0.72] | 1 | 0.287 | 0.778 |
| S0 | saved-score replay (matched study) | 0.715 [0.68, 0.84] | 23 | 0.295 | 0.804 |
| S1 | saved-score replay (matched study) | 0.715 [0.68, 0.84] | 23 | 0.313 | 0.815 |
| P0 | saved-score replay (matched study) | 0.817 [0.80, 0.84] | 7 | 0.389 | 0.876 |
| P1 | saved-score replay (matched study) | 0.817 [0.80, 0.84] | 7 | 0.411 | 0.873 |
| kmer_assay_selected | fitted here (validation-selected settings) | 0.720 [0.72, 0.72] | 1 | 0.273 | 0.780 |
| kmer_cons_selected | fitted here (validation-selected settings) | 0.840 [0.84, 0.84] | 1 | 0.298 | 0.778 |

Paired contrasts against `kmer_cons` (whole-group bootstrap, 95% percentile, unadjusted, exploratory):

| Contrast | P@25 | AP | AUROC |
|---|---|---|---|
| S0 - kmer_cons | -0.040 [-0.250, +0.208] | +0.008 [-0.039, +0.058] | +0.026 [-0.008, +0.059] |
| S1 - kmer_cons | -0.040 [-0.250, +0.208] | +0.026 [-0.021, +0.077] | +0.037 [+0.005, +0.070] |
| P0 - kmer_cons | +0.080 [-0.120, +0.304] | +0.102 [+0.061, +0.142] | +0.099 [+0.073, +0.125] |
| P1 - kmer_cons | +0.080 [-0.120, +0.304] | +0.124 [+0.083, +0.165] | +0.095 [+0.067, +0.125] |

Each bootstrap draw resamples whole groups and keeps the review fraction 25/8297, so realised shortlist depths ranged 21-31 (mean 25.0); the observed difference uses exactly 25.

Disrupting variants captured in each top 25 (registered tie order), by distance to the nearest junction in the construct; AUROC within band in brackets:

| Band (bases) | Variants | Disrupting | distance | kmer_assay | kmer_cons | S0 | S1 | P0 | P1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0-2 | 560 | 46 | 3 (0.63) | 10 (0.84) | 9 (0.83) | 8 (0.85) | 8 (0.87) | 9 (0.90) | 9 (0.90) |
| 3-10 | 1678 | 95 | 0 (0.38) | 6 (0.79) | 5 (0.77) | 6 (0.83) | 6 (0.85) | 8 (0.88) | 8 (0.89) |
| 11-30 | 4223 | 143 | 0 (0.67) | 4 (0.75) | 4 (0.75) | 3 (0.77) | 3 (0.79) | 3 (0.86) | 3 (0.86) |
| >30 | 1836 | 30 | 0 (0.52) | 0 (0.75) | 0 (0.75) | 0 (0.72) | 0 (0.71) | 0 (0.84) | 0 (0.83) |
