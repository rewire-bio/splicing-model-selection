Budget 20; common scored population 977 of 977 held-out variants (44 disrupting, 58 groups); 0 excluded.

| Configuration | Scores | P@20 expected [range over tie orders] | Tied at cutoff | AP | AUROC |
|---|---|---|---:|---:|---:|
| prevalence | computed here (one training number) | 0.045 [0.00, 1.00] | 977 | 0.045 | 0.500 |
| distance | computed here (no fitting) | 0.217 [0.10, 0.25] | 23 | 0.086 | 0.604 |
| kmer_assay | fitted here (training groups) | 0.500 [0.50, 0.50] | 1 | 0.287 | 0.755 |
| kmer_cons | fitted here (training groups) | 0.550 [0.55, 0.55] | 1 | 0.303 | 0.746 |
| S0 | saved-score replay (matched study) | 0.600 [0.60, 0.60] | 2 | 0.381 | 0.799 |
| S1 | saved-score replay (matched study) | 0.650 [0.65, 0.65] | 1 | 0.383 | 0.808 |
| P0 | saved-score replay (matched study) | 0.650 [0.65, 0.65] | 1 | 0.392 | 0.830 |
| P1 | saved-score replay (matched study) | 0.650 [0.65, 0.65] | 1 | 0.421 | 0.864 |
| kmer_assay_selected | fitted here (validation-selected settings) | 0.500 [0.50, 0.50] | 1 | 0.300 | 0.731 |
| kmer_cons_selected | fitted here (validation-selected settings) | 0.550 [0.55, 0.55] | 1 | 0.295 | 0.696 |

Paired contrasts against `kmer_cons` (whole-group bootstrap, 95% percentile, unadjusted, exploratory):

| Contrast | P@20 | AP | AUROC |
|---|---|---|---|
| S0 - kmer_cons | +0.050 [-0.095, +0.223] | +0.077 [-0.010, +0.173] | +0.052 [-0.011, +0.107] |
| S1 - kmer_cons | +0.100 [-0.053, +0.235] | +0.080 [-0.010, +0.177] | +0.062 [-0.035, +0.135] |
| P0 - kmer_cons | +0.100 [+0.000, +0.319] | +0.088 [+0.029, +0.156] | +0.084 [+0.021, +0.165] |
| P1 - kmer_cons | +0.100 [+0.000, +0.319] | +0.117 [+0.052, +0.183] | +0.118 [+0.051, +0.173] |

Each bootstrap draw resamples whole groups and keeps the review fraction 20/977, so realised shortlist depths ranged 15-26 (mean 20.0); the observed difference uses exactly 20.

Disrupting variants captured in each top 20 (registered tie order), by distance to the nearest junction in the construct; AUROC within band in brackets:

| Band (bases) | Variants | Disrupting | distance | kmer_assay | kmer_cons | S0 | S1 | P0 | P1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0-2 | 78 | 9 | 4 (0.64) | 6 (0.89) | 6 (0.92) | 6 (0.86) | 6 (0.90) | 6 (0.86) | 6 (0.90) |
| 3-10 | 201 | 11 | 0 (0.40) | 3 (0.72) | 4 (0.68) | 5 (0.87) | 5 (0.90) | 5 (0.91) | 5 (0.91) |
| 11-30 | 483 | 17 | 0 (0.54) | 1 (0.70) | 1 (0.67) | 1 (0.76) | 2 (0.72) | 2 (0.78) | 2 (0.82) |
| >30 | 215 | 7 | 0 (0.40) | 0 (0.76) | 0 (0.80) | 0 (0.66) | 0 (0.72) | 0 (0.78) | 0 (0.85) |
